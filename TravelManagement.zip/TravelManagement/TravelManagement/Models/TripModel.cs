﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TravelManagement.Models
{
    public class TripModel
    {
        public string Name { get; set; }
        public string Vehicle { get; set; }
        public int NoOfSeats { get; set; }
        public string Source { get; set; }
        public string Destination { get; set; }
        public DateTime Date { get; set; }
        public DateTime StartTime { get; set; }

        public DateTime EndTime { get; set; }
        public int Amount { get; set; }
        public bool Completed { get; set; }
        public string TripName { get; set; }

        public Dictionary<string, string> Cars { get; set; }

    }
}
